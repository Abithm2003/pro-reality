module.exports = {
  email: "abhinaathi@gmail.com",
  password: "PASSWORD",
  NEXMO_API_KEY: "API_KEY",
  NEXMO_API_SECRET: "SECRET_KEY",
  NEXMO_FROM_NUMBER: "NUMBER",
  MongoURI: 'mongodb+srv://abhinaathi:abhin123@cluster0.flgpo.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0'
}
